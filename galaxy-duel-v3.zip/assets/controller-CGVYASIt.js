var C=Object.defineProperty;var R=(p,t,e)=>t in p?C(p,t,{enumerable:!0,configurable:!0,writable:!0,value:e}):p[t]=e;var f=(p,t,e)=>R(p,typeof t!="symbol"?t+"":t,e);import{f as $,G as u}from"./fleetTally-BZJjFBBg.js";import{P as k}from"./ProceduralAudio-BZBDXwQU.js";class m{constructor(t){f(this,"layer");this.layer=t}renderFleet(t){this.layer.innerHTML="";for(const e of t)e.x<0||this.layer.appendChild(this.makeEl(e.x,e.y,e.definition.length,e.facing,e.isSunk))}renderSunkEnemies(t){this.layer.innerHTML="";for(const e of t)this.layer.appendChild(this.makeEl(e.x,e.y,e.length,e.facing,!0))}makeEl(t,e,s,l,n){const i=document.createElement("div");i.style.cssText="position:absolute;pointer-events:none;z-index:2;",l==="right"?(i.style.left=`${t*10}%`,i.style.top=`${e*10}%`,i.style.width=`${s*10}%`,i.style.height="10%"):l==="down"?(i.style.left=`${(t+1)*10}%`,i.style.top=`${e*10}%`,i.style.width=`${s*10}%`,i.style.height="10%",i.style.transformOrigin="top left",i.style.transform="rotate(90deg)"):l==="left"?(i.style.left=`${t*10}%`,i.style.top=`${e*10}%`,i.style.width=`${s*10}%`,i.style.height="10%",i.style.transformOrigin="50% 50%",i.style.transform="rotate(180deg)"):(i.style.left=`${t*10}%`,i.style.top=`${(e+s)*10}%`,i.style.width=`${s*10}%`,i.style.height="10%",i.style.transformOrigin="top left",i.style.transform="rotate(-90deg)");const r=n?"#ff3333":"#00d4ff",a=n?"drop-shadow(0 0 10px rgba(255,30,30,.65)) saturate(0.22) brightness(0.6)":"drop-shadow(0 0 7px rgba(0,212,255,.6))",o=n?`<text x="${s*50}" y="62" text-anchor="middle" font-size="26" fill="#ff4444" font-weight="bold" opacity="0.88">✕</text>`:"",d=n?`<line x1="14" y1="48" x2="${s*100-18}" y2="56" stroke="rgba(255,50,50,.22)" stroke-width="1.5"/>`:"";return i.innerHTML=`<svg style="width:100%;height:100%;filter:${a};overflow:visible"
      viewBox="0 0 ${s*100} 100" fill="none" xmlns="http://www.w3.org/2000/svg">
      ${m.paths(s,r,n)}
      ${d}${o}
    </svg>`,i}static paths(t,e,s){const l=s?"rgba(175,12,12,0.32)":"rgba(0,150,220,0.16)",n=s?"rgba(175,12,12,0.30)":"rgba(0,200,255,0.3)",i=s?"rgba(170,12,12,0.22)":"rgba(0,150,220,0.14)",r=s?"rgba(200,20,20,0.45)":"rgba(0,212,255,0.45)",a=t*100,o=10,d=a-8,h=a*.4,y=a*.62,v=a*.72,b=a*.52,L=a*.66,x=7+t,S=30+t*3,E=d-30,g=3+t*.8,I=4+t*1.2;return`
      <!-- Fuselage -->
      <path d="M ${o},50 L ${h},38 L ${d},50 L ${h},62 Z" fill="${l}" stroke="${e}" stroke-width="2.5"/>
      <!-- Delta wings -->
      <path d="M ${h},44 L ${y},8 L ${v},24 L ${b},46 Z" fill="${i}" stroke="${e}" stroke-width="1.8"/>
      <path d="M ${h},56 L ${y},92 L ${v},76 L ${b},54 Z" fill="${i}" stroke="${e}" stroke-width="1.8"/>
      <!-- Canopy -->
      <ellipse cx="${L}" cy="50" rx="${x}" ry="7" fill="${n}" stroke="${e}" stroke-width="1.4"/>
      <!-- Twin nose cannons -->
      <rect x="${E}" y="41" width="${S}" height="${g}" fill="${e}"/>
      <rect x="${E}" y="${59-g}" width="${S}" height="${g}" fill="${e}"/>
      <!-- Engine glow -->
      <circle cx="${o-4}" cy="50" r="${I}" fill="${r}"/>`}}class A{constructor(t){f(this,"playerSlot",null);f(this,"selectedShipId",null);f(this,"currentFacing","right");f(this,"lastState",null);f(this,"audio",new k);f(this,"renderers",{});f(this,"isReadyThisGame",!1);f(this,"lastPhase",null);this.ac=t}init(){this.buildDOM(),this.showView("lobby")}handleScreenMessage(t){if(B(t))switch(t.type){case"STATE_UPDATE":this.onStateUpdate(t);break;case"ATTACK_RESULT":this.onAttackResult(t);break;case"GAME_OVER":this.onGameOver(t);break}}onStateUpdate(t){switch(this.playerSlot=t.playerSlot,this.lastState=t,t.phase==="lobby"&&this.lastPhase!==null&&this.lastPhase!=="lobby"&&(this.isReadyThisGame=!1,this.selectedShipId=null,this.currentFacing="right"),this.lastPhase=t.phase,this.updatePlayerBadge(),t.phase){case"lobby":this.renderLobby(t),this.showView("lobby");break;case"placement":this.renderPlacement(t),this.showView("placement");break;case"battle":t.yourTurn?(this.renderBattleTurn(t),this.showView("battle-turn")):(this.renderBattleWait(t),this.showView("battle-wait"));break}}onAttackResult(t){if(t.sunk){this.audio.playSunk();const e=document.getElementById("global-toast");if(e){const s=t.sunkShipName?`${t.sunkShipName} `:"";e.textContent=`💥 ${s}DESTROYED!`,e.classList.add("visible"),window.setTimeout(()=>e.classList.remove("visible"),3200)}}else t.hit?this.audio.playHit():this.audio.playMiss();t.hit&&(document.body.classList.add("hit-flash"),setTimeout(()=>document.body.classList.remove("hit-flash"),400))}onGameOver(t){const e=t.winner===this.playerSlot;e?this.audio.playVictory():this.audio.playDefeat(),this.renderResult(e,t),this.showView("result")}renderLobby(t){const e=`PLAYER ${(t.playerSlot??0)+1}`,s=t.playerSlot===0?"var(--accent)":"var(--accent2)";c("#lobby-slot-name").textContent=e,c("#lobby-slot-name").style.color=s;const l=document.getElementById("lobby-you-status"),n=document.getElementById("lobby-opp-status");if(l&&(l.textContent="● Joining...",l.className="pstatus"),n&&(t.opponentConnected?(n.textContent=t.opponentReady?"✓ Ready!":"● Joining...",n.className=t.opponentReady?"pstatus ready":"pstatus"):(n.textContent="○ Waiting",n.className="pstatus dim")),!this.isReadyThisGame){const i=document.getElementById("ready-btn");i&&(i.disabled=!1,i.textContent="🚀 READY TO BATTLE",i.style.opacity="1")}}renderPlacement(t){var r;const e=c("#ship-selector");e.innerHTML="";for(const a of t.unplacedShipIds){const o=t.ships.find(v=>v.definition.id===a);if(!o)continue;const d=document.createElement("button");d.className="ship-btn btn",a===this.selectedShipId&&d.classList.add("selected"),d.dataset.shipId=a;const h=document.createElement("div");h.className="ship-segments";for(let v=0;v<o.definition.length;v++){const b=document.createElement("div");b.className="ship-seg",h.appendChild(b)}const y=document.createElement("span");y.textContent=`${o.definition.name} (${o.definition.length})`,d.appendChild(h),d.appendChild(y),d.addEventListener("click",()=>{a===this.selectedShipId?this.rotateSelectedShip():this.selectShip(a)}),e.appendChild(d)}const s=t.ships.filter(a=>a.x>=0).length,l=t.ships.length;c("#placement-progress").textContent=`${s} / ${l} placed`;const n=document.getElementById("ship-selector-label");if(n&&(n.textContent=t.unplacedShipIds.length===0?"✓ All ships placed!":"Select Ship (unplaced)"),this.selectedShipId){const a=t.ships.find(o=>o.definition.id===this.selectedShipId);a&&(this.currentFacing=a.facing)}this.updateGrid("placement-grid",t.ownBoard,!0),(r=this.renderers["placement-grid"])==null||r.renderFleet(t.ships),this.highlightPlacementSelection(t),this.updateRotateBtnLabel();const i=document.getElementById("go-to-battle-btn");if(i){const a=t.unplacedShipIds.length===0;i.style.display=a?"block":"none",a||(i.disabled=!1,i.textContent="⚔ GO TO BATTLE!",i.style.opacity="1")}}renderBattleTurn(t){var e,s;c("#ships-left").textContent=String(t.opponentShipsRemaining),this.updateGrid("own-battle-grid",t.ownBoard,!0),(e=this.renderers["own-battle-grid"])==null||e.renderFleet(t.ships),this.updateGrid("attack-grid",t.attackBoard,!1),(s=this.renderers["attack-grid"])==null||s.renderSunkEnemies(t.sunkEnemyShips),this.renderFleetTally("fleet-tally-turn",t)}renderBattleWait(t){var e,s;c("#wait-ships-left").textContent=String(t.opponentShipsRemaining),this.updateGrid("own-wait-grid",t.ownBoard,!0),(e=this.renderers["own-wait-grid"])==null||e.renderFleet(t.ships),this.updateGrid("attack-wait-grid",t.attackBoard,!1),(s=this.renderers["attack-wait-grid"])==null||s.renderSunkEnemies(t.sunkEnemyShips),this.renderFleetTally("fleet-tally-wait",t)}renderFleetTally(t,e){const s=document.getElementById(t);if(!s)return;const l=$(e.opponentShipTally),n=$(e.ownShipTally);s.innerHTML=`<div class="tally-line"><span class="tally-tag">Enemy</span> ${l}</div><div class="tally-line"><span class="tally-tag">You</span> ${n}</div>`}renderResult(t,e){const s=c("#result-banner");s.className=`status-banner ${t?"win":"lose"}`,s.textContent=t?"🏆 VICTORY!":"💥 DEFEAT",c("#result-subtitle").textContent=t?"You destroyed the enemy fleet!":"Your fleet was destroyed.";const l=document.getElementById("result-stats");if(!l||!(e!=null&&e.stats)||this.playerSlot===null)return;const n=e.stats,i=this.playerSlot,r=Math.floor(n.durationSecs/60),a=n.durationSecs%60,o=r>0?`${r}m ${a}s`:`${a}s`;l.innerHTML=`<div class="stat-row"><span>💥 Spacecraft destroyed</span><strong>${n.shipsScored[i]}</strong></div><div class="stat-row"><span>💥 Shots fired</span><strong>${n.shotsFired[i]}</strong></div><div class="stat-row"><span>⏱ Duration</span><strong>${o}</strong></div>`}highlightPlacementSelection(t){const e=c("#placement-grid").querySelectorAll(".grid-cell"),s=this.selectedShipId?this.getValidPlacementCells(this.selectedShipId,t):new Set;for(let l=0;l<u;l++)for(let n=0;n<u;n++){const i=l*u+n,r=e[i];if(!r)continue;const a=t.ownBoard[l][n].shipId,o=this.selectedShipId!==null&&a===this.selectedShipId,d=`${l},${n}`;r.classList.toggle("ship-picked",o),r.classList.toggle("place-valid",this.selectedShipId!==null&&!o&&t.ownBoard[l][n].state==="empty"&&s.has(d))}}getValidPlacementCells(t,e){const s=e.ships.find(a=>a.definition.id===t);if(!s)return new Set;const l=this.currentFacing==="right"||this.currentFacing==="left"?"horizontal":"vertical",n=s.definition.length,i=e.ownBoard.map(a=>a.map(o=>o.shipId===t?{state:"empty",shipId:null}:{...o})),r=new Set;for(let a=0;a<u;a++)for(let o=0;o<u;o++)if(this.clientCanPlace(i,n,o,a,l))for(let d=0;d<n;d++){const h=l==="horizontal"?o+d:o,y=l==="horizontal"?a:a+d;r.add(`${y},${h}`)}return r}showGhostPreview(t,e,s){var d;if(!this.lastState||!this.selectedShipId)return;const l=this.lastState.ships.find(h=>h.definition.id===this.selectedShipId);if(!l)return;const n=l.definition.length,i=document.querySelector("#placement-grid");if(!i)return;(d=i.querySelector(".ghost-preview"))==null||d.remove();const r=this.lastState.ownBoard.map(h=>h.map(y=>y.shipId===this.selectedShipId?{state:"empty",shipId:null}:{...y}));if(!this.clientCanPlace(r,n,t,e,s))return;const a=document.createElement("div");a.className="ghost-preview";const o=100/u;s==="horizontal"?(a.style.left=`${t*o}%`,a.style.top=`${e*o}%`,a.style.width=`${n*o}%`,a.style.height=`${o}%`):(a.style.left=`${t*o}%`,a.style.top=`${e*o}%`,a.style.width=`${o}%`,a.style.height=`${n*o}%`),i.appendChild(a),setTimeout(()=>a.remove(),1500)}clientCanPlace(t,e,s,l,n){const i=Array.from({length:e},(r,a)=>n==="horizontal"?[s+a,l]:[s,l+a]);if(!i.every(([r,a])=>r>=0&&r<u&&a>=0&&a<u))return!1;for(const[r,a]of i)for(let o=-1;o<=1;o++)for(let d=-1;d<=1;d++){const h=r+d,y=a+o;if(!(h<0||h>=u||y<0||y>=u)&&t[y][h].state==="ship")return!1}return!0}updateRotateBtnLabel(){const t=document.getElementById("rotate-btn");if(!t)return;const e={right:"→ Facing Right",down:"↓ Facing Down",left:"← Facing Left",up:"↑ Facing Up"};t.textContent=e[this.currentFacing]}updateGrid(t,e,s){const n=c(`#${t}`).querySelectorAll(".grid-cell");for(let i=0;i<u;i++)for(let r=0;r<u;r++){const a=i*u+r,o=n[a];if(!o)continue;const d=e[i][r].state;o.className="grid-cell",d!=="empty"&&o.classList.add(d),s&&d==="empty"&&(o.style.cursor="default")}}buildGrid(t,e){const s=c(`#${t}`);s.innerHTML="";for(let i=0;i<u;i++)for(let r=0;r<u;r++){const a=document.createElement("button");a.type="button",a.className="grid-cell",e?a.addEventListener("click",()=>e(r,i)):(a.style.cursor="default",a.tabIndex=-1),s.appendChild(a)}const l=document.createElement("div");l.className="ships-layer",s.appendChild(l),this.renderers[t]=new m(l);const n=document.createElement("div");n.className="grid-row-labels",n.setAttribute("aria-hidden","true"),"ABCDEFGHIJ".split("").forEach(i=>{const r=document.createElement("span");r.textContent=i,n.appendChild(r)}),s.appendChild(n)}rotateSelectedShip(){if(!this.selectedShipId)return;this.ac.message(this.ac.SCREEN,{type:"ROTATE_SHIP",shipId:this.selectedShipId});const t=["right","down","left","up"];this.currentFacing=t[(t.indexOf(this.currentFacing)+1)%4],this.updateRotateBtnLabel()}selectShip(t){var s,l,n;this.selectedShipId=t;const e=(s=this.lastState)==null?void 0:s.ships.find(i=>i.definition.id===t);e&&(this.currentFacing=e.facing),document.querySelectorAll(".ship-btn").forEach(i=>i.classList.remove("selected")),(l=document.querySelector(`[data-ship-id="${t}"]`))==null||l.classList.add("selected"),((n=this.lastState)==null?void 0:n.phase)==="placement"&&(this.highlightPlacementSelection(this.lastState),this.updateRotateBtnLabel())}showView(t){document.querySelectorAll(".view").forEach(s=>s.classList.remove("active"));const e=document.getElementById(`view-${t}`);e&&e.classList.add("active")}updatePlayerBadge(){if(this.playerSlot===null)return;const t=document.getElementById("player-badge");t&&(t.textContent=`PLAYER ${this.playerSlot+1}`,t.className=`player-badge p${this.playerSlot+1}`)}buildDOM(){const t=Array.from({length:10},(l,n)=>`<div class="grid-col-label">${n+1}</div>`).join(""),e=document.getElementById("controller-root");e.innerHTML=`
      <div id="player-badge"></div>
      <div id="global-toast" class="global-toast" role="status" aria-live="polite"></div>

      <!-- LOBBY -->
      <div id="view-lobby" class="view">
        <div class="game-title" style="margin-top:24px">GALAXY<br/>DUEL</div>

        <div class="card" style="margin-top:4px">
          <div class="section-label">Your Slot</div>
          <div id="lobby-slot-name" style="font-size:1.6rem;font-family:'Sora',sans-serif;font-weight:800;color:var(--accent);text-align:center;padding:4px 0">—</div>
        </div>

        <div class="card">
          <div class="section-label">Lobby Status</div>
          <div class="player-row" style="max-width:100%">
            <div class="player-tile you"><div class="pname">YOU</div><div class="pstatus" id="lobby-you-status">● Joining...</div></div>
            <div class="player-tile opp"><div class="pname">OPPONENT</div><div class="pstatus dim" id="lobby-opp-status">○ Waiting</div></div>
          </div>
        </div>

        <button id="ready-btn" class="btn btn-primary">🚀 READY TO BATTLE</button>
        <p class="pulse" style="font-size:.72rem;color:var(--text-dim);text-align:center">Tap when ready to start</p>
      </div>

      <!-- PLACEMENT: grid first on small screens so it stays visible; ships scroll below -->
      <div id="view-placement" class="view view-placement">
        <div class="placement-title">DEPLOY FLEET</div>
        <p id="placement-progress" class="placement-progress">0 / 10 placed</p>
        <p class="placement-hint">Tap a ship to select it → tap grid to place. Tap a selected ship again to rotate. Tap a placed ship to move it.</p>

        <div class="btn-row">
          <button type="button" class="btn-half" id="rotate-btn">↻ Rotate (H)</button>
          <button type="button" class="btn-half" id="auto-place-btn">🎲 Auto</button>
        </div>

        <div class="placement-main">
          <div class="card card-grid">
            <div class="section-label">Your Grid</div>
            <div class="grid-header">${t}</div>
            <div id="placement-grid" class="grid" aria-label="Fleet placement grid"></div>
          </div>

          <div class="card card-ships">
            <div class="section-label" id="ship-selector-label">Select Ship (unplaced)</div>
            <div id="ship-selector"></div>
          </div>
        </div>
        <button type="button" id="go-to-battle-btn" class="btn btn-primary" style="display:none;margin-top:12px">⚔ GO TO BATTLE!</button>
      </div>

      <!-- BATTLE — YOUR TURN -->
      <div id="view-battle-turn" class="view view-battle">
        <div class="status-banner your-turn pulse" style="margin-top:16px;position:relative">
          ⚡ YOUR TURN — FIRE!
        </div>
        <div class="ships-counter">Enemy spacecraft remaining: <strong id="ships-left">?</strong></div>
        <div id="fleet-tally-turn" class="fleet-tally"></div>
        <div class="battle-grids">
          <div class="card card-battle">
            <div class="section-label">Your Fleet</div>
            <div class="grid-header battle-h">${t}</div>
            <div id="own-battle-grid" class="grid grid--compact"></div>
          </div>
          <div class="card card-battle">
            <div class="section-label">Enemy Sector — Tap to Fire</div>
            <div class="grid-header battle-h">${t}</div>
            <div id="attack-grid" class="grid grid--compact"></div>
          </div>
        </div>
      </div>

      <!-- BATTLE — WAITING -->
      <div id="view-battle-wait" class="view view-battle">
        <div class="status-banner waiting pulse" style="margin-top:16px">⏳ OPPONENT'S TURN</div>
        <div class="ships-counter">Enemy spacecraft remaining: <strong id="wait-ships-left">?</strong></div>
        <div id="fleet-tally-wait" class="fleet-tally"></div>
        <div class="battle-grids">
          <div class="card card-battle">
            <div class="section-label">Your Fleet</div>
            <div class="grid-header battle-h">${t}</div>
            <div id="own-wait-grid" class="grid grid--compact"></div>
          </div>
          <div class="card card-battle">
            <div class="section-label">Your Hits</div>
            <div class="grid-header battle-h">${t}</div>
            <div id="attack-wait-grid" class="grid grid--compact"></div>
          </div>
        </div>
        <p style="font-size:.78rem;color:var(--text-dim);text-align:center">Waiting for opponent's turn…</p>
      </div>

      <!-- RESULT -->
      <div id="view-result" class="view">
        <div style="margin-top:40px"></div>
        <div id="result-banner" class="status-banner win">—</div>
        <p id="result-subtitle" style="font-size:.8rem;color:var(--text-dim);text-align:center"></p>
        <div id="result-stats" class="result-stats"></div>
        <button id="restart-btn" class="btn btn-primary" style="margin-top:16px">🚀 PLAY AGAIN</button>
      </div>
    `,this.buildGrid("placement-grid",(l,n)=>this.onPlacementTap(l,n)),this.buildGrid("own-battle-grid"),this.buildGrid("attack-grid",(l,n)=>this.onAttackTap(l,n)),this.buildGrid("own-wait-grid"),this.buildGrid("attack-wait-grid"),c("#ready-btn").addEventListener("click",()=>{this.audio.playReady(),this.isReadyThisGame=!0,this.ac.message(this.ac.SCREEN,{type:"READY"}),c("#ready-btn").disabled=!0,c("#ready-btn").textContent="✓ READY!",c("#ready-btn").style.opacity="0.7"}),c("#rotate-btn").addEventListener("click",()=>{if(this.selectedShipId)this.rotateSelectedShip();else{const l=["right","down","left","up"];this.currentFacing=l[(l.indexOf(this.currentFacing)+1)%4],this.updateRotateBtnLabel()}}),c("#auto-place-btn").addEventListener("click",()=>{this.autoPlaceShips()}),c("#go-to-battle-btn").addEventListener("click",()=>{const l=document.getElementById("go-to-battle-btn");l.disabled=!0,l.textContent="✓ READY FOR BATTLE!",l.style.opacity="0.7",this.ac.message(this.ac.SCREEN,{type:"CONFIRM_PLACEMENT"})}),c("#restart-btn").addEventListener("click",()=>{this.ac.message(this.ac.SCREEN,{type:"RESTART_GAME"})});const s=document.getElementById("player-badge");s&&(s.style.display="block")}onPlacementTap(t,e){var n;if(!this.lastState||this.lastState.phase!=="placement")return;const s=(n=this.lastState.ownBoard[e])==null?void 0:n[t];if(!s)return;if(s.state==="ship"&&s.shipId){s.shipId===this.selectedShipId?this.rotateSelectedShip():this.selectShip(s.shipId);return}if(!this.selectedShipId)return;const l=this.currentFacing==="right"||this.currentFacing==="left"?"horizontal":"vertical";this.showGhostPreview(t,e,l),this.audio.playPlaceShip(),this.ac.message(this.ac.SCREEN,{type:"PLACE_SHIP",shipId:this.selectedShipId,x:t,y:e,orientation:l,facing:this.currentFacing})}onAttackTap(t,e){var l;if(!this.lastState)return;const s=(l=this.lastState.attackBoard[e])==null?void 0:l[t];s&&s.state!=="empty"||(this.audio.playShot(),this.ac.message(this.ac.SCREEN,{type:"ATTACK_CELL",x:t,y:e}))}autoPlaceShips(){this.ac.message(this.ac.SCREEN,{type:"AUTO_PLACE"})}}function c(p){const t=document.querySelector(p);if(!t)throw new Error(`Element not found: ${p}`);return t}function B(p){return typeof p=="object"&&p!==null&&"type"in p&&typeof p.type=="string"}const w=new AirConsole({orientation:"portrait"}),T=new A(w);w.onReady=()=>T.init();w.onMessage=(p,t)=>T.handleScreenMessage(t);
