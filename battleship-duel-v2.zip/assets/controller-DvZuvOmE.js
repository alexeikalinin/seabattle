var x=Object.defineProperty;var $=(d,t,e)=>t in d?x(d,t,{enumerable:!0,configurable:!0,writable:!0,value:e}):d[t]=e;var p=(d,t,e)=>$(d,typeof t!="symbol"?t+"":t,e);import{f as k,G as y}from"./fleetTally-8QImcF_y.js";import{P as S}from"./ProceduralAudio-BVNtAijT.js";class f{constructor(t){p(this,"layer");this.layer=t}renderFleet(t){this.layer.innerHTML="";for(const e of t)e.x<0||this.layer.appendChild(this.makeEl(e.x,e.y,e.definition.length,e.facing,e.isSunk))}renderSunkEnemies(t){this.layer.innerHTML="";for(const e of t)this.layer.appendChild(this.makeEl(e.x,e.y,e.length,e.facing,!0))}makeEl(t,e,i,l,a){const s=document.createElement("div");s.style.cssText="position:absolute;pointer-events:none;z-index:2;",l==="right"?(s.style.left=`${t*10}%`,s.style.top=`${e*10}%`,s.style.width=`${i*10}%`,s.style.height="10%"):l==="down"?(s.style.left=`${(t+1)*10}%`,s.style.top=`${e*10}%`,s.style.width=`${i*10}%`,s.style.height="10%",s.style.transformOrigin="top left",s.style.transform="rotate(90deg)"):l==="left"?(s.style.left=`${t*10}%`,s.style.top=`${e*10}%`,s.style.width=`${i*10}%`,s.style.height="10%",s.style.transformOrigin="50% 50%",s.style.transform="rotate(180deg)"):(s.style.left=`${t*10}%`,s.style.top=`${(e+i)*10}%`,s.style.width=`${i*10}%`,s.style.height="10%",s.style.transformOrigin="top left",s.style.transform="rotate(-90deg)");const n=a?"#ff3333":"#00d4ff",r=a?"drop-shadow(0 0 10px rgba(255,30,30,.65)) saturate(0.22) brightness(0.6)":"drop-shadow(0 0 7px rgba(0,212,255,.6))",c=a?`<text x="${i*50}" y="62" text-anchor="middle" font-size="26" fill="#ff4444" font-weight="bold" opacity="0.88">✕</text>`:"",h=a?`<line x1="14" y1="48" x2="${i*100-18}" y2="56" stroke="rgba(255,50,50,.22)" stroke-width="1.5"/>`:"";return s.innerHTML=`<svg style="width:100%;height:100%;filter:${r};overflow:visible"
      viewBox="0 0 ${i*100} 100" fill="none" xmlns="http://www.w3.org/2000/svg">
      ${f.paths(i,n,a)}
      ${h}${c}
    </svg>`,s}static paths(t,e,i){const l=i?"rgba(175,12,12,0.32)":"rgba(0,150,220,0.15)",a=i?"rgba(175,12,12,0.30)":"rgba(0,180,255,0.28)",s=i?"rgba(170,12,12,0.30)":"rgba(0,175,255,0.34)",n=i?"rgba(175,12,12,0.25)":"rgba(0,165,235,0.18)",r=i?"rgba(200,20,20,0.45)":"rgba(0,212,255,0.45)";switch(t){case 4:return`
        <!-- Carrier: flat flight deck, angled port deck, island starboard -->
        <path d="M 14,25 L 356,18 Q 392,50 356,82 L 14,75 Q 6,50 14,25 Z" fill="${l}" stroke="${e}" stroke-width="2.5"/>
        <path d="M 40,75 L 270,75 L 252,96 L 40,92 Z" fill="${i?"rgba(160,10,10,.18)":"rgba(0,130,200,.10)"}" stroke="${e}" stroke-width="1.5" opacity="0.7"/>
        <!-- Island superstructure -->
        <rect x="252" y="20" width="58" height="20" rx="3" fill="${a}" stroke="${e}" stroke-width="2"/>
        <rect x="256" y="23" width="50" height="8" rx="2" fill="${i?"rgba(170,8,8,.2)":"rgba(0,210,255,.15)"}" stroke="${e}" stroke-width="1"/>
        <!-- Mast -->
        <line x1="290" y1="20" x2="290" y2="10" stroke="${e}" stroke-width="2.5" opacity="0.65"/>
        <rect x="278" y="7" width="24" height="6" rx="2" fill="${a}" stroke="${e}" stroke-width="1.5"/>
        <!-- Catapults -->
        <line x1="280" y1="22" x2="382" y2="37" stroke="${e}" stroke-width="1" opacity="${i?.18:.35}"/>
        <line x1="280" y1="30" x2="376" y2="43" stroke="${e}" stroke-width="1" opacity="${i?.18:.35}"/>
        <!-- Arrestor wires -->
        <line x1="118" y1="68" x2="110" y2="95" stroke="${e}" stroke-width=".8" opacity="${i?.15:.28}"/>
        <line x1="136" y1="68" x2="128" y2="95" stroke="${e}" stroke-width=".8" opacity="${i?.15:.28}"/>
        <!-- Deck centerline -->
        <line x1="35" y1="50" x2="340" y2="50" stroke="${e}" stroke-width=".6" stroke-dasharray="18,12" opacity="0.18"/>
        <!-- Stern engines -->
        <rect x="14" y="34" width="10" height="32" rx="2" fill="${s}" stroke="${e}" stroke-width="1.2"/>
        <circle cx="390" cy="50" r="5" fill="${r}"/>`;case 3:return`
        <!-- Slava-class cruiser: twin turrets fore/aft, missile tubes, bridge -->
        <path d="M 12,22 L 258,14 Q 292,50 258,86 L 12,78 Q 5,50 12,22 Z" fill="${l}" stroke="${e}" stroke-width="2.5"/>
        <!-- Fore twin turret -->
        <circle cx="50" cy="50" r="13" fill="${a}" stroke="${e}" stroke-width="2"/>
        <line x1="50" y1="47" x2="70" y2="44" stroke="${e}" stroke-width="3.5" stroke-linecap="round"/>
        <line x1="50" y1="53" x2="70" y2="56" stroke="${e}" stroke-width="3.5" stroke-linecap="round"/>
        <!-- Bridge superstructure -->
        <path d="M 80,30 L 130,26 L 130,74 L 80,70 Z" fill="${n}" stroke="${e}" stroke-width="1.8"/>
        <!-- Radar dome -->
        <circle cx="108" cy="26" r="8" fill="${a}" stroke="${e}" stroke-width="1.5"/>
        <circle cx="108" cy="26" r="4" fill="${i?"rgba(200,20,20,.5)":"rgba(0,215,255,.55)"}"/>
        <!-- Missile tubes port -->
        <rect x="84" y="14" width="14" height="5.5" rx="1.5" fill="${s}" stroke="${e}" stroke-width="1.2"/>
        <rect x="102" y="13" width="14" height="5.5" rx="1.5" fill="${s}" stroke="${e}" stroke-width="1.2"/>
        <rect x="120" y="13" width="14" height="5.5" rx="1.5" fill="${s}" stroke="${e}" stroke-width="1.2"/>
        <!-- Missile tubes starboard -->
        <rect x="84" y="80.5" width="14" height="5.5" rx="1.5" fill="${s}" stroke="${e}" stroke-width="1.2"/>
        <rect x="102" y="81.5" width="14" height="5.5" rx="1.5" fill="${s}" stroke="${e}" stroke-width="1.2"/>
        <rect x="120" y="81.5" width="14" height="5.5" rx="1.5" fill="${s}" stroke="${e}" stroke-width="1.2"/>
        <!-- Aft superstructure -->
        <rect x="146" y="32" width="52" height="36" rx="4" fill="${n}" stroke="${e}" stroke-width="1.5"/>
        <!-- Funnel -->
        <rect x="165" y="28" width="18" height="12" rx="3" fill="${a}" stroke="${e}" stroke-width="1.5"/>
        <!-- Aft turret -->
        <circle cx="222" cy="50" r="12" fill="${a}" stroke="${e}" stroke-width="2"/>
        <line x1="222" y1="47" x2="242" y2="44" stroke="${e}" stroke-width="3" stroke-linecap="round"/>
        <line x1="222" y1="53" x2="242" y2="56" stroke="${e}" stroke-width="3" stroke-linecap="round"/>
        <!-- Helo deck stern -->
        <circle cx="16" cy="50" r="10" fill="none" stroke="${e}" stroke-width="1.2" opacity="0.4"/>
        <line x1="9" y1="50" x2="23" y2="50" stroke="${e}" stroke-width=".8" opacity="0.35"/>
        <line x1="16" y1="43" x2="16" y2="57" stroke="${e}" stroke-width=".8" opacity="0.35"/>
        <circle cx="287" cy="50" r="4" fill="${r}"/>`;case 2:return`
        <!-- Arleigh Burke destroyer: stealth facets, Mk45 gun, SPY-1 radar, VLS -->
        <path d="M 12,26 L 168,16 Q 192,50 168,84 L 12,74 Q 5,50 12,26 Z" fill="${l}" stroke="${e}" stroke-width="2.5"/>
        <!-- Stealth faceting lines -->
        <line x1="12" y1="26" x2="75" y2="18" stroke="${e}" stroke-width=".8" opacity=".28"/>
        <line x1="12" y1="74" x2="75" y2="82" stroke="${e}" stroke-width=".8" opacity=".28"/>
        <!-- Mk 45 gun mount -->
        <path d="M 36,40 L 62,36 L 68,50 L 62,64 L 36,60 Z" fill="${a}" stroke="${e}" stroke-width="1.8"/>
        <line x1="62" y1="50" x2="82" y2="50" stroke="${e}" stroke-width="3.5" stroke-linecap="round"/>
        <!-- Bridge (pyramid stealth) -->
        <path d="M 82,28 L 128,24 L 132,50 L 128,76 L 82,72 Z" fill="${n}" stroke="${e}" stroke-width="1.8"/>
        <!-- SPY-1 phased array panels -->
        <rect x="90" y="26" width="20" height="13" rx="2" fill="${a}" stroke="${e}" stroke-width="1.5"/>
        <rect x="90" y="61" width="20" height="13" rx="2" fill="${a}" stroke="${e}" stroke-width="1.5"/>
        <!-- VLS cells fore -->
        <rect x="86" y="38" width="8" height="24" rx="1.5" fill="${s}" stroke="${e}" stroke-width="1.2"/>
        <!-- VLS cells aft -->
        <rect x="140" y="34" width="10" height="32" rx="1.5" fill="${s}" stroke="${e}" stroke-width="1.2"/>
        <!-- Helo deck -->
        <circle cx="20" cy="50" r="9" fill="none" stroke="${e}" stroke-width="1.2" opacity="0.4"/>
        <line x1="13" y1="50" x2="27" y2="50" stroke="${e}" stroke-width=".8" opacity=".35"/>
        <line x1="20" y1="43" x2="20" y2="57" stroke="${e}" stroke-width=".8" opacity=".35"/>
        <circle cx="188" cy="50" r="4" fill="${r}"/>`;default:return`
        <!-- Virginia-class submarine: teardrop hull, sail, periscopes -->
        <ellipse cx="48" cy="50" rx="40" ry="24" fill="${l}" stroke="${e}" stroke-width="2.5"/>
        <!-- Sail (conning tower) -->
        <rect x="36" y="28" width="20" height="16" rx="3" fill="${a}" stroke="${e}" stroke-width="2"/>
        <!-- Periscopes -->
        <line x1="42" y1="28" x2="42" y2="20" stroke="${e}" stroke-width="2.5" stroke-linecap="round" opacity="${i?.3:.7}"/>
        <line x1="50" y1="28" x2="50" y2="16" stroke="${e}" stroke-width="2.5" stroke-linecap="round" opacity="${i?.3:.7}"/>
        <circle cx="42" cy="20" r="2.5" fill="${e}" opacity="${i?.25:.65}"/>
        <circle cx="50" cy="16" r="3" fill="${e}" opacity="${i?.25:.7}"/>
        <!-- Rudder cross -->
        <line x1="10" y1="44" x2="10" y2="56" stroke="${e}" stroke-width="2.5" opacity="0.4" stroke-linecap="round"/>
        <line x1="6" y1="50" x2="18" y2="50" stroke="${e}" stroke-width="2.5" opacity="0.4" stroke-linecap="round"/>
        <circle cx="87" cy="50" r="3.5" fill="${r}"/>`}}}class E{constructor(t){p(this,"playerSlot",null);p(this,"selectedShipId",null);p(this,"currentFacing","right");p(this,"lastState",null);p(this,"audio",new S);p(this,"renderers",{});p(this,"isReadyThisGame",!1);p(this,"lastPhase",null);this.ac=t}init(){this.buildDOM(),this.showView("lobby")}handleScreenMessage(t){if(L(t))switch(t.type){case"STATE_UPDATE":this.onStateUpdate(t);break;case"ATTACK_RESULT":this.onAttackResult(t);break;case"GAME_OVER":this.onGameOver(t);break}}onStateUpdate(t){switch(this.playerSlot=t.playerSlot,this.lastState=t,t.phase==="lobby"&&this.lastPhase!==null&&this.lastPhase!=="lobby"&&(this.isReadyThisGame=!1,this.selectedShipId=null,this.currentFacing="right"),this.lastPhase=t.phase,this.updatePlayerBadge(),t.phase){case"lobby":this.renderLobby(t),this.showView("lobby");break;case"placement":this.renderPlacement(t),this.showView("placement");break;case"battle":t.yourTurn?(this.renderBattleTurn(t),this.showView("battle-turn")):(this.renderBattleWait(t),this.showView("battle-wait"));break}}onAttackResult(t){if(t.sunk){this.audio.playSunk();const e=document.getElementById("global-toast");if(e){const i=t.sunkShipName?`${t.sunkShipName} `:"";e.textContent=`⚓ ${i}SUNK!`,e.classList.add("visible"),window.setTimeout(()=>e.classList.remove("visible"),3200)}}else t.hit?this.audio.playHit():this.audio.playMiss();t.hit&&(document.body.classList.add("hit-flash"),setTimeout(()=>document.body.classList.remove("hit-flash"),400))}onGameOver(t){const e=t.winner===this.playerSlot;e?this.audio.playVictory():this.audio.playDefeat(),this.renderResult(e),this.showView("result")}renderLobby(t){const e=`PLAYER ${(t.playerSlot??0)+1}`,i=t.playerSlot===0?"var(--accent)":"var(--accent2)";o("#lobby-slot-name").textContent=e,o("#lobby-slot-name").style.color=i;const l=document.getElementById("lobby-you-status"),a=document.getElementById("lobby-opp-status");if(l&&(l.textContent="● Joining...",l.className="pstatus"),a&&(t.opponentConnected?(a.textContent=t.opponentReady?"✓ Ready!":"● Joining...",a.className=t.opponentReady?"pstatus ready":"pstatus"):(a.textContent="○ Waiting",a.className="pstatus dim")),!this.isReadyThisGame){const s=document.getElementById("ready-btn");s&&(s.disabled=!1,s.textContent="⚓ READY TO BATTLE",s.style.opacity="1")}}renderPlacement(t){var n;const e=o("#ship-selector");e.innerHTML="";for(const r of t.unplacedShipIds){const c=t.ships.find(u=>u.definition.id===r);if(!c)continue;const h=document.createElement("button");h.className="ship-btn btn",r===this.selectedShipId&&h.classList.add("selected"),h.dataset.shipId=r;const b=document.createElement("div");b.className="ship-segments";for(let u=0;u<c.definition.length;u++){const v=document.createElement("div");v.className="ship-seg",b.appendChild(v)}const w=document.createElement("span");w.textContent=`${c.definition.name} (${c.definition.length})`,h.appendChild(b),h.appendChild(w),h.addEventListener("click",()=>{r===this.selectedShipId?this.rotateSelectedShip():this.selectShip(r)}),e.appendChild(h)}const i=t.ships.filter(r=>r.x>=0).length,l=t.ships.length;o("#placement-progress").textContent=`${i} / ${l} placed`;const a=document.getElementById("ship-selector-label");if(a&&(a.textContent=t.unplacedShipIds.length===0?"✓ All ships placed!":"Select Ship (unplaced)"),this.selectedShipId){const r=t.ships.find(c=>c.definition.id===this.selectedShipId);r&&(this.currentFacing=r.facing)}this.updateGrid("placement-grid",t.ownBoard,!0),(n=this.renderers["placement-grid"])==null||n.renderFleet(t.ships),this.highlightPlacementSelection(t),this.updateRotateBtnLabel();const s=document.getElementById("go-to-battle-btn");if(s){const r=t.unplacedShipIds.length===0;s.style.display=r?"block":"none",r||(s.disabled=!1,s.textContent="⚔ GO TO BATTLE!",s.style.opacity="1")}}renderBattleTurn(t){var e,i;o("#ships-left").textContent=String(t.opponentShipsRemaining),this.updateGrid("own-battle-grid",t.ownBoard,!0),(e=this.renderers["own-battle-grid"])==null||e.renderFleet(t.ships),this.updateGrid("attack-grid",t.attackBoard,!1),(i=this.renderers["attack-grid"])==null||i.renderSunkEnemies(t.sunkEnemyShips),this.renderFleetTally("fleet-tally-turn",t)}renderBattleWait(t){var e,i;o("#wait-ships-left").textContent=String(t.opponentShipsRemaining),this.updateGrid("own-wait-grid",t.ownBoard,!0),(e=this.renderers["own-wait-grid"])==null||e.renderFleet(t.ships),this.updateGrid("attack-wait-grid",t.attackBoard,!1),(i=this.renderers["attack-wait-grid"])==null||i.renderSunkEnemies(t.sunkEnemyShips),this.renderFleetTally("fleet-tally-wait",t)}renderFleetTally(t,e){const i=document.getElementById(t);if(!i)return;const l=k(e.opponentShipTally),a=k(e.ownShipTally);i.innerHTML=`<div class="tally-line"><span class="tally-tag">Enemy</span> ${l}</div><div class="tally-line"><span class="tally-tag">You</span> ${a}</div>`}renderResult(t){const e=o("#result-banner");e.className=`status-banner ${t?"win":"lose"}`,e.textContent=t?"🏆 VICTORY!":"💥 DEFEAT",o("#result-subtitle").textContent=t?"You sunk the enemy fleet!":"Your fleet was destroyed."}highlightPlacementSelection(t){const e=o("#placement-grid").querySelectorAll(".grid-cell");for(let i=0;i<y;i++)for(let l=0;l<y;l++){const a=i*y+l,s=e[a];if(!s)continue;const n=t.ownBoard[i][l].shipId,r=this.selectedShipId!==null&&n===this.selectedShipId;s.classList.toggle("ship-picked",r)}}updateRotateBtnLabel(){const t=document.getElementById("rotate-btn");if(!t)return;const e={right:"→ Facing Right",down:"↓ Facing Down",left:"← Facing Left",up:"↑ Facing Up"};t.textContent=e[this.currentFacing]}updateGrid(t,e,i){const a=o(`#${t}`).querySelectorAll(".grid-cell");for(let s=0;s<y;s++)for(let n=0;n<y;n++){const r=s*y+n,c=a[r];if(!c)continue;const h=e[s][n].state;c.className="grid-cell",h!=="empty"&&c.classList.add(h),i&&h==="empty"&&(c.style.cursor="default")}}buildGrid(t,e){const i=o(`#${t}`);i.innerHTML="";for(let s=0;s<y;s++)for(let n=0;n<y;n++){const r=document.createElement("button");r.type="button",r.className="grid-cell",e?r.addEventListener("click",()=>e(n,s)):(r.style.cursor="default",r.tabIndex=-1),i.appendChild(r)}const l=document.createElement("div");l.className="ships-layer",i.appendChild(l),this.renderers[t]=new f(l);const a=document.createElement("div");a.className="grid-row-labels",a.setAttribute("aria-hidden","true"),"ABCDEFGHIJ".split("").forEach(s=>{const n=document.createElement("span");n.textContent=s,a.appendChild(n)}),i.appendChild(a)}rotateSelectedShip(){if(!this.selectedShipId)return;this.ac.message(this.ac.SCREEN,{type:"ROTATE_SHIP",shipId:this.selectedShipId});const t=["right","down","left","up"];this.currentFacing=t[(t.indexOf(this.currentFacing)+1)%4],this.updateRotateBtnLabel()}selectShip(t){var i,l,a;this.selectedShipId=t;const e=(i=this.lastState)==null?void 0:i.ships.find(s=>s.definition.id===t);e&&(this.currentFacing=e.facing),document.querySelectorAll(".ship-btn").forEach(s=>s.classList.remove("selected")),(l=document.querySelector(`[data-ship-id="${t}"]`))==null||l.classList.add("selected"),((a=this.lastState)==null?void 0:a.phase)==="placement"&&(this.highlightPlacementSelection(this.lastState),this.updateRotateBtnLabel())}showView(t){document.querySelectorAll(".view").forEach(i=>i.classList.remove("active"));const e=document.getElementById(`view-${t}`);e&&e.classList.add("active")}updatePlayerBadge(){if(this.playerSlot===null)return;const t=document.getElementById("player-badge");t&&(t.textContent=`PLAYER ${this.playerSlot+1}`,t.className=`player-badge p${this.playerSlot+1}`)}buildDOM(){const t=Array.from({length:10},(l,a)=>`<div class="grid-col-label">${a+1}</div>`).join(""),e=document.getElementById("controller-root");e.innerHTML=`
      <div id="player-badge"></div>
      <div id="global-toast" class="global-toast" role="status" aria-live="polite"></div>

      <!-- LOBBY -->
      <div id="view-lobby" class="view">
        <div class="game-title" style="margin-top:24px">BATTLESHIP<br/>DUEL</div>

        <div class="card" style="margin-top:4px">
          <div class="section-label">Your Slot</div>
          <div id="lobby-slot-name" style="font-size:1.6rem;font-family:'Sora',sans-serif;font-weight:800;color:var(--accent);text-align:center;padding:4px 0">—</div>
        </div>

        <div class="card">
          <div class="section-label">Lobby Status</div>
          <div class="player-row" style="max-width:100%">
            <div class="player-tile you"><div class="pname">YOU</div><div class="pstatus" id="lobby-you-status">● Joining...</div></div>
            <div class="player-tile opp"><div class="pname">OPPONENT</div><div class="pstatus dim" id="lobby-opp-status">○ Waiting</div></div>
          </div>
        </div>

        <button id="ready-btn" class="btn btn-primary">⚓ READY TO BATTLE</button>
        <p class="pulse" style="font-size:.72rem;color:var(--text-dim);text-align:center">Tap when ready to start</p>
      </div>

      <!-- PLACEMENT: grid first on small screens so it stays visible; ships scroll below -->
      <div id="view-placement" class="view view-placement">
        <div class="placement-title">DEPLOY FLEET</div>
        <p id="placement-progress" class="placement-progress">0 / 10 placed</p>
        <p class="placement-hint">Tap a ship to select it → tap grid to place. Tap a selected ship again to rotate. Tap a placed ship to move it.</p>

        <div class="btn-row">
          <button type="button" class="btn-half" id="rotate-btn">↻ Rotate (H)</button>
          <button type="button" class="btn-half" id="auto-place-btn">🎲 Auto</button>
        </div>

        <div class="placement-main">
          <div class="card card-grid">
            <div class="section-label">Your Grid</div>
            <div class="grid-header">${t}</div>
            <div id="placement-grid" class="grid" aria-label="Fleet placement grid"></div>
          </div>

          <div class="card card-ships">
            <div class="section-label" id="ship-selector-label">Select Ship (unplaced)</div>
            <div id="ship-selector"></div>
          </div>
        </div>
        <button type="button" id="go-to-battle-btn" class="btn btn-primary" style="display:none;margin-top:12px">⚔ GO TO BATTLE!</button>
      </div>

      <!-- BATTLE — YOUR TURN -->
      <div id="view-battle-turn" class="view view-battle">
        <div class="status-banner your-turn pulse" style="margin-top:16px">⚡ YOUR TURN — FIRE!</div>
        <div class="ships-counter">Enemy ships remaining: <strong id="ships-left">?</strong></div>
        <div id="fleet-tally-turn" class="fleet-tally"></div>
        <div class="battle-grids">
          <div class="card card-battle">
            <div class="section-label">Your Fleet</div>
            <div class="grid-header battle-h">${t}</div>
            <div id="own-battle-grid" class="grid grid--compact"></div>
          </div>
          <div class="card card-battle">
            <div class="section-label">Enemy Waters — Tap to Fire</div>
            <div class="grid-header battle-h">${t}</div>
            <div id="attack-grid" class="grid grid--compact"></div>
          </div>
        </div>
      </div>

      <!-- BATTLE — WAITING -->
      <div id="view-battle-wait" class="view view-battle">
        <div class="status-banner waiting pulse" style="margin-top:16px">⏳ OPPONENT'S TURN</div>
        <div class="ships-counter">Enemy ships remaining: <strong id="wait-ships-left">?</strong></div>
        <div id="fleet-tally-wait" class="fleet-tally"></div>
        <div class="battle-grids">
          <div class="card card-battle">
            <div class="section-label">Your Fleet</div>
            <div class="grid-header battle-h">${t}</div>
            <div id="own-wait-grid" class="grid grid--compact"></div>
          </div>
          <div class="card card-battle">
            <div class="section-label">Your Hits</div>
            <div class="grid-header battle-h">${t}</div>
            <div id="attack-wait-grid" class="grid grid--compact"></div>
          </div>
        </div>
        <p style="font-size:.78rem;color:var(--text-dim);text-align:center">Waiting for opponent's turn…</p>
      </div>

      <!-- RESULT -->
      <div id="view-result" class="view">
        <div style="margin-top:40px"></div>
        <div id="result-banner" class="status-banner win">—</div>
        <p id="result-subtitle" style="font-size:.8rem;color:var(--text-dim);text-align:center"></p>
        <button id="restart-btn" class="btn btn-primary" style="margin-top:32px">⚓ PLAY AGAIN</button>
      </div>
    `,this.buildGrid("placement-grid",(l,a)=>this.onPlacementTap(l,a)),this.buildGrid("own-battle-grid"),this.buildGrid("attack-grid",(l,a)=>this.onAttackTap(l,a)),this.buildGrid("own-wait-grid"),this.buildGrid("attack-wait-grid"),o("#ready-btn").addEventListener("click",()=>{this.audio.playReady(),this.isReadyThisGame=!0,this.ac.message(this.ac.SCREEN,{type:"READY"}),o("#ready-btn").disabled=!0,o("#ready-btn").textContent="✓ READY!",o("#ready-btn").style.opacity="0.7"}),o("#rotate-btn").addEventListener("click",()=>{if(this.selectedShipId)this.rotateSelectedShip();else{const l=["right","down","left","up"];this.currentFacing=l[(l.indexOf(this.currentFacing)+1)%4],this.updateRotateBtnLabel()}}),o("#auto-place-btn").addEventListener("click",()=>{this.autoPlaceShips()}),o("#go-to-battle-btn").addEventListener("click",()=>{const l=document.getElementById("go-to-battle-btn");l.disabled=!0,l.textContent="✓ READY FOR BATTLE!",l.style.opacity="0.7",this.ac.message(this.ac.SCREEN,{type:"CONFIRM_PLACEMENT"})}),o("#restart-btn").addEventListener("click",()=>{this.ac.message(this.ac.SCREEN,{type:"RESTART_GAME"})});const i=document.getElementById("player-badge");i&&(i.style.display="block")}onPlacementTap(t,e){var l;if(!this.lastState||this.lastState.phase!=="placement")return;const i=(l=this.lastState.ownBoard[e])==null?void 0:l[t];if(i){if(i.state==="ship"&&i.shipId){i.shipId===this.selectedShipId?this.rotateSelectedShip():this.selectShip(i.shipId);return}this.selectedShipId&&(this.audio.playPlaceShip(),this.ac.message(this.ac.SCREEN,{type:"PLACE_SHIP",shipId:this.selectedShipId,x:t,y:e,orientation:this.currentFacing==="right"||this.currentFacing==="left"?"horizontal":"vertical",facing:this.currentFacing}))}}onAttackTap(t,e){var l;if(!this.lastState)return;const i=(l=this.lastState.attackBoard[e])==null?void 0:l[t];i&&i.state!=="empty"||(this.audio.playShot(),this.ac.message(this.ac.SCREEN,{type:"ATTACK_CELL",x:t,y:e}))}autoPlaceShips(){this.ac.message(this.ac.SCREEN,{type:"AUTO_PLACE"})}}function o(d){const t=document.querySelector(d);if(!t)throw new Error(`Element not found: ${d}`);return t}function L(d){return typeof d=="object"&&d!==null&&"type"in d&&typeof d.type=="string"}const g=new AirConsole({orientation:"portrait"}),m=new E(g);g.onReady=()=>m.init();g.onMessage=(d,t)=>m.handleScreenMessage(t);
